package com.dev.bbs.exception;

public class UpdationFailedException extends Exception {
	private static final long serialVersionUID = 1L;

	public UpdationFailedException(String excep) {
		super(excep);
	}

}
