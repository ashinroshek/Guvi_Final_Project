package com.dev.bbs.exception;

public class BusNotFoundException extends Exception {
	private static final long serialVersionUID = 1L;

	public BusNotFoundException(String s) {
		super(s);
	}

}
