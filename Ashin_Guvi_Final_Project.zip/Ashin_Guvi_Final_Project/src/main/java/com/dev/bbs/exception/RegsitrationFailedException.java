package com.dev.bbs.exception;

public class RegsitrationFailedException extends Exception {
	private static final long serialVersionUID = 1L;

	public RegsitrationFailedException(String excep) {
		super(excep);
	}

}
